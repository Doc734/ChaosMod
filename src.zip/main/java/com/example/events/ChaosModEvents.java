package com.example.events;

import com.example.ChaosMod;
import com.example.config.ChaosModConfig;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.List;
import java.util.Random;

public class ChaosModEvents {
    private static final Random random = new Random();
    
    public static void register() {
        // 注册伤害事件
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof PlayerEntity player) {
                return handlePlayerDamage(player, source, amount);
            }
            return true;
        });
        
        // 注册伤害后事件
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof PlayerEntity player) {
                handlePlayerDeath(player, source);
            }
        });
        
        // 注册实体攻击事件
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof MobEntity mob && source.getAttacker() instanceof PlayerEntity player) {
                return handleMobDamage(mob, player, source, amount);
            }
            return true;
        });
        
        // 注册服务器tick事件
        ServerTickEvents.END_SERVER_TICK.register(ChaosModEvents::onServerTick);
    }
    
    private static boolean handlePlayerDamage(PlayerEntity player, DamageSource source, float amount) {
        ChaosModConfig config = ChaosMod.config;
        
        // 共享生命值效果
        if (config.sharedHealthEnabled) {
            return handleSharedHealth(player, source, amount);
        }
        
        // 共享平摊伤害效果
        if (config.sharedDamageSplitEnabled) {
            return handleSharedDamageSplit(player, source, amount);
        }
        
        // 随机伤害效果
        if (config.randomDamageEnabled) {
            return handleRandomDamage(player, source, amount);
        }
        
        // 玩家贴在一起平摊伤害
        if (config.playerDamageShareEnabled) {
            return handlePlayerDamageShare(player, source, amount);
        }
        
        return true;
    }
    
    private static boolean handleSharedHealth(PlayerEntity player, DamageSource source, float amount) {
        // 完整实现：所有玩家共享生命值，一个受伤其他也受伤
        World world = player.getWorld();
        if (world instanceof net.minecraft.server.world.ServerWorld serverWorld) {
            List<ServerPlayerEntity> players = serverWorld.getServer().getPlayerManager().getPlayerList();
            
            for (ServerPlayerEntity otherPlayer : players) {
                if (otherPlayer != player && otherPlayer.isAlive()) {
                    otherPlayer.damage(source, amount);
                }
            }
        }
        
        return true;
    }
    
    private static boolean handleSharedDamageSplit(PlayerEntity player, DamageSource source, float amount) {
        // 完整实现：受伤平分给所有玩家
        World world = player.getWorld();
        if (world instanceof net.minecraft.server.world.ServerWorld serverWorld) {
            List<ServerPlayerEntity> players = serverWorld.getServer().getPlayerManager().getPlayerList();
            
            float splitAmount = amount / players.size();
            
            for (ServerPlayerEntity otherPlayer : players) {
                if (otherPlayer.isAlive()) {
                    otherPlayer.damage(source, splitAmount);
                }
            }
        }
        
        return false; // 阻止原始伤害
    }
    
    private static boolean handleRandomDamage(PlayerEntity player, DamageSource source, float amount) {
        // 完整实现：随机将伤害转移到其他玩家
        World world = player.getWorld();
        if (world instanceof net.minecraft.server.world.ServerWorld serverWorld) {
            List<ServerPlayerEntity> players = serverWorld.getServer().getPlayerManager().getPlayerList();
            
            if (players.size() > 1) {
                ServerPlayerEntity randomPlayer = players.get(random.nextInt(players.size()));
                randomPlayer.damage(source, amount);
            }
        }
        
        return false; // 阻止原始伤害
    }
    
    private static boolean handlePlayerDamageShare(PlayerEntity player, DamageSource source, float amount) {
        // 完整实现：检查附近是否有其他玩家
        World world = player.getWorld();
        Box searchBox = new Box(player.getPos().add(-2, -2, -2), player.getPos().add(2, 2, 2));
        List<PlayerEntity> nearbyPlayers = world.getEntitiesByClass(PlayerEntity.class, searchBox, 
            p -> p != player && p.isAlive());
        
        if (!nearbyPlayers.isEmpty()) {
            float splitAmount = amount / (nearbyPlayers.size() + 1);
            
            // 伤害所有附近的玩家
            for (PlayerEntity nearbyPlayer : nearbyPlayers) {
                nearbyPlayer.damage(source, splitAmount);
            }
        }
        
        return true; // 允许原始伤害，但会被平摊
    }
    
    private static boolean handleMobDamage(MobEntity mob, PlayerEntity player, DamageSource source, float amount) {
        ChaosModConfig config = ChaosMod.config;
        
        // 怪物反伤效果
        if (config.mobThornsEnabled) {
            player.damage(player.getDamageSources().thorns(mob), amount * 0.5f);
        }
        
        return true;
    }
    
    private static void handlePlayerDeath(PlayerEntity player, DamageSource source) {
        ChaosModConfig config = ChaosMod.config;
        
        // 末影龙击杀玩家
        if (config.enderDragonKillEnabled && source.getAttacker() instanceof PlayerEntity attacker) {
            if (source.getAttacker().getType() == EntityType.ENDER_DRAGON) {
                attacker.kill();
                attacker.sendMessage(Text.literal("你击杀了末影龙，但也被杀死了！"), false);
            }
        }
    }
    
    private static void onServerTick(MinecraftServer server) {
        ChaosModConfig config = ChaosMod.config;
        
        // 检查低血量无法回血效果
        if (config.lowHealthNoHealEnabled) {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                if (player.getHealth() <= 2.0f && !config.noHealActive) {
                    if (random.nextFloat() < 0.5f) { // 50%概率
                        config.noHealActive = true;
                        config.noHealEndTime = server.getTicks() + 400; // 20秒
                        // 添加无法回血效果
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 400, 0));
                        player.sendMessage(Text.literal("你受到了诅咒，无法回血20秒！"), false);
                    }
                }
            }
        }
        
        // 检查无法回血效果是否结束
        if (config.noHealActive && server.getTicks() >= config.noHealEndTime) {
            config.noHealActive = false;
            config.markDirty();
        }
        
        // 所有生物敌对效果已移到EntityMixin中处理
    }
}