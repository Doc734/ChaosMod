package com.example.effects;

import com.example.ChaosMod;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ChaosModEffects {
    public static final StatusEffect NO_HEAL_EFFECT = new NoHealEffect(StatusEffectCategory.HARMFUL, 0xFF0000);
    
    public static void register() {
        Registry.register(Registries.STATUS_EFFECT, Identifier.of(ChaosMod.MOD_ID, "no_heal"), NO_HEAL_EFFECT);
    }
}
