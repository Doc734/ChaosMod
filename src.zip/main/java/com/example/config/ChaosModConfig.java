package com.example.config;

public class ChaosModConfig {
    // 所有效果的开关状态，默认为false
    public boolean foodPoisonEnabled = false;
    public boolean mobIgniteEnabled = false;
    public boolean mobSlownessEnabled = false;
    public boolean mobBlindnessEnabled = false;
    public boolean mobThornsEnabled = false;
    public boolean enderDragonBucketEnabled = false;
    public boolean enderDragonKillEnabled = false;
    public boolean playerDamageShareEnabled = false;
    public boolean shieldNerfEnabled = false;
    public boolean allHostileEnabled = false;
    public boolean randomDamageEnabled = false;
    public boolean lowHealthNoHealEnabled = false;
    public boolean sharedHealthEnabled = false;
    public boolean sharedDamageSplitEnabled = false;
    
    // 特殊状态
    public boolean noHealActive = false;
    public long noHealEndTime = 0;
    
    public ChaosModConfig() {
        // 默认构造函数
    }
    
    public void markDirty() {
        // 简化版本，不需要持久化
    }
}