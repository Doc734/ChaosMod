package com.example.mixin;

import com.example.ChaosMod;
import com.example.config.ChaosModConfig;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(PlayerEntity.class)
public class PlayerEntityMixin {
    
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        PlayerEntity player = (PlayerEntity) (Object) this;
        
        if (player.getWorld().isClient) return;
        
        ChaosModConfig config = ChaosMod.config;
        if (config == null) return;
        
        // 末影龙攻击后水桶变牛奶桶 - 完整实现
        if (config.enderDragonBucketEnabled) {
            checkEnderDragonBucketEffect(player);
        }
        
        // 所有生物敌对效果已移到服务端事件中处理
    }
    
    private void checkEnderDragonBucketEffect(PlayerEntity player) {
        // 检查玩家是否被末影龙攻击 - 完整实现
        if (player.getWorld() instanceof net.minecraft.server.world.ServerWorld serverWorld) {
            // 检查玩家周围是否有末影龙
            Box searchBox = new Box(player.getPos().add(-50, -50, -50), player.getPos().add(50, 50, 50));
            List<net.minecraft.entity.boss.dragon.EnderDragonEntity> enderDragons = 
                serverWorld.getEntitiesByClass(net.minecraft.entity.boss.dragon.EnderDragonEntity.class, searchBox, 
                    dragon -> dragon.isAlive() && dragon.getTarget() == player);
            
            if (!enderDragons.isEmpty()) {
                // 如果末影龙正在攻击玩家，转换水桶
                convertWaterBucketsToMilk(player);
            }
        }
    }
    
    private void makeAllMobsHostile(PlayerEntity player) {
        // 完整实现：所有生物都会主动攻击玩家
        World world = player.getWorld();
        List<MobEntity> mobs = world.getEntitiesByClass(MobEntity.class, 
            new Box(player.getPos().add(-50, -50, -50), player.getPos().add(50, 50, 50)), 
            mob -> mob.isAlive());
        
        for (MobEntity mob : mobs) {
            if (mob.getTarget() == null || !mob.getTarget().equals(player)) {
                mob.setTarget(player);
            }
        }
    }
    
    private void convertWaterBucketsToMilk(PlayerEntity player) {
        // 完整实现：转换背包中所有水桶为牛奶桶
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.getItem() == Items.WATER_BUCKET) {
                player.getInventory().setStack(i, new ItemStack(Items.MILK_BUCKET, stack.getCount()));
            }
        }
    }
}