package com.example.mixin;

import com.example.ChaosMod;
import com.example.config.ChaosModConfig;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Random;

@Mixin(Item.class)
public class FoodItemMixin {
    private static final Random random = new Random();
    
    @Inject(method = "finishUsing", at = @At("HEAD"))
    private void onFinishUsing(ItemStack stack, net.minecraft.world.World world, LivingEntity user, CallbackInfoReturnable<ItemStack> cir) {
        if (world.isClient) return;
        if (!(user instanceof PlayerEntity)) return;
        
        ChaosModConfig config = ChaosMod.config;
        if (config == null) return;
        
        // 食物中毒效果 - 完整实现
        if (config.foodPoisonEnabled) {
            FoodComponent foodComponent = stack.get(DataComponentTypes.FOOD);
            if (foodComponent != null) {
                // 30%概率中毒
                if (random.nextFloat() < 0.3f) {
                    user.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 200, 0)); // 10秒中毒
                }
            }
        }
    }
}