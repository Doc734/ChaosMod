package com.example.mixin;

import com.example.ChaosMod;
import com.example.config.ChaosModConfig;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.passive.WanderingTraderEntity;
import net.minecraft.entity.passive.FishEntity;
import net.minecraft.entity.passive.SquidEntity;
import net.minecraft.entity.passive.AxolotlEntity;
import net.minecraft.entity.passive.FrogEntity;
import net.minecraft.entity.passive.TurtleEntity;
import net.minecraft.entity.passive.AllayEntity;
import net.minecraft.entity.passive.SnifferEntity;
import net.minecraft.entity.passive.StriderEntity;
import net.minecraft.entity.passive.GoatEntity;
import net.minecraft.entity.passive.PufferfishEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.SnowGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class EntityMixin {
    
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        Entity entity = (Entity) (Object) this;
        
        if (entity.getWorld().isClient) return;
        if (!(entity instanceof LivingEntity)) return;
        
        ChaosModConfig config = ChaosMod.config;
        if (config == null) return;
        
        // 所有生物敌对效果 - 完整实现
        if (config.allHostileEnabled) {
            LivingEntity livingEntity = (LivingEntity) entity;
            
            // 跳过玩家
            if (livingEntity instanceof PlayerEntity) return;
            
            // 让所有生物对最近的玩家敌对
            PlayerEntity nearestPlayer = entity.getWorld().getClosestPlayer(entity, 50.0);
            if (nearestPlayer != null) {
                // 强制让所有生物攻击玩家
                if (livingEntity instanceof MobEntity mob) {
                    mob.setTarget(nearestPlayer);
                } else if (livingEntity instanceof AnimalEntity animal) {
                    animal.setTarget(nearestPlayer);
                } else if (livingEntity instanceof PassiveEntity passive) {
                    passive.setTarget(nearestPlayer);
                } else if (livingEntity instanceof VillagerEntity villager) {
                    villager.setTarget(nearestPlayer);
                } else if (livingEntity instanceof WanderingTraderEntity trader) {
                    trader.setTarget(nearestPlayer);
                } else if (livingEntity instanceof FishEntity fish) {
                    fish.setTarget(nearestPlayer);
                } else if (livingEntity instanceof SquidEntity squid) {
                    squid.setTarget(nearestPlayer);
                } else if (livingEntity instanceof AxolotlEntity axolotl) {
                    axolotl.setTarget(nearestPlayer);
                } else if (livingEntity instanceof FrogEntity frog) {
                    frog.setTarget(nearestPlayer);
                } else if (livingEntity instanceof TurtleEntity turtle) {
                    turtle.setTarget(nearestPlayer);
                } else if (livingEntity instanceof AllayEntity allay) {
                    allay.setTarget(nearestPlayer);
                } else if (livingEntity instanceof SnifferEntity sniffer) {
                    sniffer.setTarget(nearestPlayer);
                } else if (livingEntity instanceof StriderEntity strider) {
                    strider.setTarget(nearestPlayer);
                } else if (livingEntity instanceof GoatEntity goat) {
                    goat.setTarget(nearestPlayer);
                } else if (livingEntity instanceof PufferfishEntity pufferfish) {
                    pufferfish.setTarget(nearestPlayer);
                } else if (livingEntity instanceof IronGolemEntity golem) {
                    golem.setTarget(nearestPlayer);
                } else if (livingEntity instanceof SnowGolemEntity snowGolem) {
                    snowGolem.setTarget(nearestPlayer);
                }
            }
        }
    }
}
