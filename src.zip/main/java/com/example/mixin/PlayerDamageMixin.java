package com.example.mixin;

import com.example.ChaosMod;
import com.example.config.ChaosModConfig;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public class PlayerDamageMixin {
    
    @Inject(method = "damage", at = @At("HEAD"))
    private void onPlayerDamage(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        PlayerEntity player = (PlayerEntity) (Object) this;
        
        if (player.getWorld().isClient) return;
        
        ChaosModConfig config = ChaosMod.config;
        if (config == null) return;
        
        // 被怪物攻击时的效果 - 完整实现
        if (source.getAttacker() instanceof MobEntity mob) {
            // 被怪物打中点燃
            if (config.mobIgniteEnabled) {
                player.setFireTicks(100); // 5秒点燃
            }
            
            // 被怪物打中缓慢
            if (config.mobSlownessEnabled) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1)); // 5秒缓慢2
            }
            
            // 被怪物打中失明
            if (config.mobBlindnessEnabled) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 20, 0)); // 1秒失明
            }
        }
        
        // 末影龙击杀死亡效果 - 完整实现
        if (config.enderDragonKillEnabled && source.getAttacker() != null) {
            if (source.getAttacker().getType() == net.minecraft.entity.EntityType.ENDER_DRAGON) {
                // 如果玩家被末影龙攻击，检查是否是击杀
                if (player.getHealth() - amount <= 0) {
                    // 玩家即将死亡，杀死攻击者（末影龙）
                    source.getAttacker().kill();
                    player.sendMessage(Text.literal("你被末影龙杀死了，但末影龙也死了！"), false);
                }
            }
        }
    }
}