package com.example.mixin;

import com.example.ChaosMod;
import com.example.config.ChaosModConfig;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Random;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {
    private static final Random random = new Random();
    
    @Inject(method = "heal", at = @At("HEAD"), cancellable = true)
    private void onHeal(float amount, CallbackInfo ci) {
        LivingEntity entity = (LivingEntity) (Object) this;
        
        if (entity.getWorld().isClient) return;
        if (!(entity instanceof PlayerEntity)) return;
        
        ChaosModConfig config = ChaosMod.config;
        if (config == null) return;
        
        // 低血量无法回血效果 - 完整实现
        if (config.lowHealthNoHealEnabled && config.noHealActive) {
            ci.cancel();
            return;
        }
    }
    
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void onDamage(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        LivingEntity entity = (LivingEntity) (Object) this;
        
        if (entity.getWorld().isClient) return;
        if (!(entity instanceof PlayerEntity)) return;
        
        ChaosModConfig config = ChaosMod.config;
        if (config == null) return;
        
        PlayerEntity player = (PlayerEntity) entity;
        
        // 怪物反伤效果已移到PlayerAttackMixin中处理
        
        // 检查是否被末影龙攻击 - 完整实现
        if (config.enderDragonBucketEnabled && source.getAttacker() != null) {
            if (source.getAttacker().getType() == net.minecraft.entity.EntityType.ENDER_DRAGON) {
                convertWaterBucketsToMilk(player);
            }
        }
        
        // 共享生命值效果 - 完整实现
        if (config.sharedHealthEnabled) {
            handleSharedHealth(player, source, amount);
            cir.setReturnValue(true);
            return;
        }
        
        // 共享平摊伤害效果 - 完整实现
        if (config.sharedDamageSplitEnabled) {
            handleSharedDamageSplit(player, source, amount);
            cir.setReturnValue(true);
            return;
        }
        
        // 随机伤害效果 - 完整实现
        if (config.randomDamageEnabled) {
            handleRandomDamage(player, source, amount);
            cir.setReturnValue(true);
            return;
        }
        
        // 玩家贴在一起平摊伤害 - 完整实现
        if (config.playerDamageShareEnabled) {
            handlePlayerDamageShare(player, source, amount);
            cir.setReturnValue(true);
            return;
        }
    }
    
    private void handleSharedHealth(PlayerEntity player, DamageSource source, float amount) {
        // 完整实现：所有玩家共享生命值，一个受伤其他也受伤
        World world = player.getWorld();
        if (world instanceof net.minecraft.server.world.ServerWorld serverWorld) {
            List<ServerPlayerEntity> players = serverWorld.getServer().getPlayerManager().getPlayerList();
            
            for (ServerPlayerEntity otherPlayer : players) {
                if (otherPlayer != player && otherPlayer.isAlive()) {
                    otherPlayer.damage(source, amount);
                }
            }
        }
    }
    
    private void handleSharedDamageSplit(PlayerEntity player, DamageSource source, float amount) {
        // 完整实现：受伤平分给所有玩家
        World world = player.getWorld();
        if (world instanceof net.minecraft.server.world.ServerWorld serverWorld) {
            List<ServerPlayerEntity> players = serverWorld.getServer().getPlayerManager().getPlayerList();
            
            float splitAmount = amount / players.size();
            
            for (ServerPlayerEntity otherPlayer : players) {
                if (otherPlayer.isAlive()) {
                    otherPlayer.damage(source, splitAmount);
                }
            }
        }
    }
    
    private void handleRandomDamage(PlayerEntity player, DamageSource source, float amount) {
        // 完整实现：随机将伤害转移到其他玩家
        World world = player.getWorld();
        if (world instanceof net.minecraft.server.world.ServerWorld serverWorld) {
            List<ServerPlayerEntity> players = serverWorld.getServer().getPlayerManager().getPlayerList();
            
            if (players.size() > 1) {
                ServerPlayerEntity randomPlayer = players.get(random.nextInt(players.size()));
                randomPlayer.damage(source, amount);
            }
        }
    }
    
    private void handlePlayerDamageShare(PlayerEntity player, DamageSource source, float amount) {
        // 完整实现：检查附近是否有其他玩家
        World world = player.getWorld();
        Box searchBox = new Box(player.getPos().add(-2, -2, -2), player.getPos().add(2, 2, 2));
        List<PlayerEntity> nearbyPlayers = world.getEntitiesByClass(PlayerEntity.class, searchBox, 
            p -> p != player && p.isAlive());
        
        if (!nearbyPlayers.isEmpty()) {
            float splitAmount = amount / (nearbyPlayers.size() + 1);
            
            // 伤害所有附近的玩家
            for (PlayerEntity nearbyPlayer : nearbyPlayers) {
                nearbyPlayer.damage(source, splitAmount);
            }
        }
    }
    
    private void convertWaterBucketsToMilk(PlayerEntity player) {
        // 完整实现：转换背包中所有水桶为牛奶桶
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.getItem() == Items.WATER_BUCKET) {
                player.getInventory().setStack(i, new ItemStack(Items.MILK_BUCKET, stack.getCount()));
            }
        }
    }
}