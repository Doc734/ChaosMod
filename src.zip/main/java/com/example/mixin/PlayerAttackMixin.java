package com.example.mixin;

import com.example.ChaosMod;
import com.example.config.ChaosModConfig;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntity.class)
public class PlayerAttackMixin {
    
    @Inject(method = "attack", at = @At("HEAD"))
    private void onPlayerAttack(net.minecraft.entity.Entity target, CallbackInfo ci) {
        PlayerEntity player = (PlayerEntity) (Object) this;
        
        if (player.getWorld().isClient) return;
        
        ChaosModConfig config = ChaosMod.config;
        if (config == null) return;
        
        // 怪物反伤效果 - 完整实现
        if (config.mobThornsEnabled && target instanceof MobEntity mob) {
            // 当玩家攻击怪物时，怪物对玩家造成反伤
            float damage = 1.0f; // 基础反伤伤害
            player.damage(player.getDamageSources().thorns(mob), damage);
        }
    }
}
