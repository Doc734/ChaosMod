package com.example.commands;

import com.example.ChaosMod;
import com.example.config.ChaosModConfig;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ClickableChaosCommands {
    
    public static void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher, CommandRegistryAccess registryAccess) {
        dispatcher.register(CommandManager.literal("chaos")
            .requires(source -> source.hasPermissionLevel(2))
            .executes(ClickableChaosCommands::showMainMenu));
    }
    
    public static int showMainMenu(CommandContext<ServerCommandSource> context) {
        ChaosModConfig config = ChaosMod.config;
        
        // 主菜单
        net.minecraft.text.MutableText mainMenu = Text.literal("§6=== 混乱模组主菜单 ===\n")
            .append(Text.literal("§f点击下面的选项来切换效果状态\n\n"));
        
        // 添加所有效果的可点击按钮
        mainMenu = mainMenu.append(createEffectButton("食物中毒", "foodpoison", config.foodPoisonEnabled));
        mainMenu = mainMenu.append(Text.literal(" "));
        mainMenu = mainMenu.append(createEffectButton("怪物点燃", "mobignite", config.mobIgniteEnabled));
        mainMenu = mainMenu.append(Text.literal("\n"));
        
        mainMenu = mainMenu.append(createEffectButton("怪物缓慢", "mobslowness", config.mobSlownessEnabled));
        mainMenu = mainMenu.append(Text.literal(" "));
        mainMenu = mainMenu.append(createEffectButton("怪物失明", "mobblindness", config.mobBlindnessEnabled));
        mainMenu = mainMenu.append(Text.literal("\n"));
        
        mainMenu = mainMenu.append(createEffectButton("怪物反伤", "mobthorns", config.mobThornsEnabled));
        mainMenu = mainMenu.append(Text.literal(" "));
        mainMenu = mainMenu.append(createEffectButton("末影龙水桶变牛奶", "enderdragonbucket", config.enderDragonBucketEnabled));
        mainMenu = mainMenu.append(Text.literal("\n"));
        
        mainMenu = mainMenu.append(createEffectButton("末影龙击杀死亡", "enderdragonkill", config.enderDragonKillEnabled));
        mainMenu = mainMenu.append(Text.literal(" "));
        mainMenu = mainMenu.append(createEffectButton("玩家平摊伤害", "playerdamageshare", config.playerDamageShareEnabled));
        mainMenu = mainMenu.append(Text.literal("\n"));
        
        mainMenu = mainMenu.append(createEffectButton("所有生物敌对", "allhostile", config.allHostileEnabled));
        mainMenu = mainMenu.append(Text.literal(" "));
        mainMenu = mainMenu.append(createEffectButton("随机伤害", "randomdamage", config.randomDamageEnabled));
        mainMenu = mainMenu.append(Text.literal("\n"));
        
        mainMenu = mainMenu.append(createEffectButton("低血量无法回血", "lowhealthnoheal", config.lowHealthNoHealEnabled));
        mainMenu = mainMenu.append(Text.literal(" "));
        mainMenu = mainMenu.append(createEffectButton("共享生命值", "sharedhealth", config.sharedHealthEnabled));
        mainMenu = mainMenu.append(Text.literal("\n"));
        
        mainMenu = mainMenu.append(createEffectButton("共享平摊伤害", "shareddamagesplit", config.sharedDamageSplitEnabled));
        mainMenu = mainMenu.append(Text.literal("\n\n"));
        
        // 添加特殊按钮
        mainMenu = mainMenu.append(createSpecialButton("§a查看状态", "status", "点击查看所有效果状态"));
        mainMenu = mainMenu.append(Text.literal(" "));
        mainMenu = mainMenu.append(createSpecialButton("§c重置所有", "reset", "点击重置所有效果为关闭状态"));
        mainMenu = mainMenu.append(Text.literal("\n"));
        
        mainMenu = mainMenu.append(createSpecialButton("§e刷新菜单", "refresh", "点击刷新当前菜单"));
        
        final net.minecraft.text.MutableText finalMainMenu = mainMenu;
        context.getSource().sendFeedback(() -> finalMainMenu, false);
        return 1;
    }
    
    private static Text createEffectButton(String displayName, String effectId, boolean isEnabled) {
        String status = isEnabled ? "§a[开启]" : "§c[关闭]";
        String action = isEnabled ? "关闭" : "开启";
        
        return Text.literal("§f" + displayName + " " + status)
            .setStyle(Style.EMPTY
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/chaos toggle " + effectId))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, 
                    Text.literal("点击" + action + " " + displayName)))
                .withFormatting(Formatting.UNDERLINE));
    }
    
    private static Text createSpecialButton(String displayName, String command, String hoverText) {
        return Text.literal(displayName)
            .setStyle(Style.EMPTY
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/chaos " + command))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal(hoverText)))
                .withFormatting(Formatting.UNDERLINE));
    }
    
    // 处理切换命令
    public static void handleToggle(ServerCommandSource source, String effectId) {
        ChaosModConfig config = ChaosMod.config;
        boolean newState = !getEffectState(config, effectId);
        setEffectState(config, effectId, newState);
        
        String effectName = getEffectName(effectId);
        String status = newState ? "§a开启" : "§c关闭";
        
        source.sendFeedback(() -> Text.literal("§6[混乱模组] §f" + effectName + " 已" + status), true);
        
        // 自动刷新菜单
        // showMainMenu(null); // 暂时注释掉，避免递归调用
    }
    
    // 处理状态查看
    public static void handleStatus(ServerCommandSource source) {
        ChaosModConfig config = ChaosMod.config;
        
        StringBuilder status = new StringBuilder("§6=== 混乱模组状态 ===\n");
        status.append("§f食物中毒: ").append(config.foodPoisonEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f怪物点燃: ").append(config.mobIgniteEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f怪物缓慢: ").append(config.mobSlownessEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f怪物失明: ").append(config.mobBlindnessEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f怪物反伤: ").append(config.mobThornsEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f末影龙水桶变牛奶: ").append(config.enderDragonBucketEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f末影龙击杀死亡: ").append(config.enderDragonKillEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f玩家平摊伤害: ").append(config.playerDamageShareEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f所有生物敌对: ").append(config.allHostileEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f随机伤害: ").append(config.randomDamageEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f低血量无法回血: ").append(config.lowHealthNoHealEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f共享生命值: ").append(config.sharedHealthEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f共享平摊伤害: ").append(config.sharedDamageSplitEnabled ? "§a开启" : "§c关闭");
        
        source.sendFeedback(() -> Text.literal(status.toString()), false);
    }
    
    // 处理重置
    public static void handleReset(ServerCommandSource source) {
        ChaosModConfig config = ChaosMod.config;
        
        config.foodPoisonEnabled = false;
        config.mobIgniteEnabled = false;
        config.mobSlownessEnabled = false;
        config.mobBlindnessEnabled = false;
        config.mobThornsEnabled = false;
        config.enderDragonBucketEnabled = false;
        config.enderDragonKillEnabled = false;
        config.playerDamageShareEnabled = false;
        config.allHostileEnabled = false;
        config.randomDamageEnabled = false;
        config.lowHealthNoHealEnabled = false;
        config.sharedHealthEnabled = false;
        config.sharedDamageSplitEnabled = false;
        config.noHealActive = false;
        config.noHealEndTime = 0;
        
        config.markDirty();
        
        source.sendFeedback(() -> Text.literal("§6[混乱模组] §f所有效果已重置为关闭状态"), true);
    }
    
    private static boolean getEffectState(ChaosModConfig config, String effect) {
        return switch (effect) {
            case "foodpoison" -> config.foodPoisonEnabled;
            case "mobignite" -> config.mobIgniteEnabled;
            case "mobslowness" -> config.mobSlownessEnabled;
            case "mobblindness" -> config.mobBlindnessEnabled;
            case "mobthorns" -> config.mobThornsEnabled;
            case "enderdragonbucket" -> config.enderDragonBucketEnabled;
            case "enderdragonkill" -> config.enderDragonKillEnabled;
            case "playerdamageshare" -> config.playerDamageShareEnabled;
            case "allhostile" -> config.allHostileEnabled;
            case "randomdamage" -> config.randomDamageEnabled;
            case "lowhealthnoheal" -> config.lowHealthNoHealEnabled;
            case "sharedhealth" -> config.sharedHealthEnabled;
            case "shareddamagesplit" -> config.sharedDamageSplitEnabled;
            default -> false;
        };
    }
    
    private static void setEffectState(ChaosModConfig config, String effect, boolean state) {
        switch (effect) {
            case "foodpoison" -> config.foodPoisonEnabled = state;
            case "mobignite" -> config.mobIgniteEnabled = state;
            case "mobslowness" -> config.mobSlownessEnabled = state;
            case "mobblindness" -> config.mobBlindnessEnabled = state;
            case "mobthorns" -> config.mobThornsEnabled = state;
            case "enderdragonbucket" -> config.enderDragonBucketEnabled = state;
            case "enderdragonkill" -> config.enderDragonKillEnabled = state;
            case "playerdamageshare" -> config.playerDamageShareEnabled = state;
            case "allhostile" -> config.allHostileEnabled = state;
            case "randomdamage" -> config.randomDamageEnabled = state;
            case "lowhealthnoheal" -> config.lowHealthNoHealEnabled = state;
            case "sharedhealth" -> config.sharedHealthEnabled = state;
            case "shareddamagesplit" -> config.sharedDamageSplitEnabled = state;
        }
        config.markDirty();
    }
    
    private static String getEffectName(String effect) {
        return switch (effect) {
            case "foodpoison" -> "食物中毒";
            case "mobignite" -> "怪物点燃";
            case "mobslowness" -> "怪物缓慢";
            case "mobblindness" -> "怪物失明";
            case "mobthorns" -> "怪物反伤";
            case "enderdragonbucket" -> "末影龙水桶变牛奶";
            case "enderdragonkill" -> "末影龙击杀死亡";
            case "playerdamageshare" -> "玩家平摊伤害";
            case "allhostile" -> "所有生物敌对";
            case "randomdamage" -> "随机伤害";
            case "lowhealthnoheal" -> "低血量无法回血";
            case "sharedhealth" -> "共享生命值";
            case "shareddamagesplit" -> "共享平摊伤害";
            default -> "未知效果";
        };
    }
}
