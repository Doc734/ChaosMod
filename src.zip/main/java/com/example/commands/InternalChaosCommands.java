package com.example.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

public class InternalChaosCommands {
    
    public static void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher, CommandRegistryAccess registryAccess) {
        // 处理内部切换命令
        dispatcher.register(CommandManager.literal("chaos")
            .requires(source -> source.hasPermissionLevel(2))
            .then(CommandManager.literal("toggle")
                .then(CommandManager.argument("effect", StringArgumentType.string())
                    .executes(InternalChaosCommands::handleToggle)))
            .then(CommandManager.literal("status")
                .executes(InternalChaosCommands::handleStatus))
            .then(CommandManager.literal("reset")
                .executes(InternalChaosCommands::handleReset))
            .then(CommandManager.literal("refresh")
                .executes(InternalChaosCommands::handleRefresh)));
    }
    
    private static int handleToggle(CommandContext<ServerCommandSource> context) {
        String effect = StringArgumentType.getString(context, "effect");
        ClickableChaosCommands.handleToggle(context.getSource(), effect);
        return 1;
    }
    
    private static int handleStatus(CommandContext<ServerCommandSource> context) {
        ClickableChaosCommands.handleStatus(context.getSource());
        return 1;
    }
    
    private static int handleReset(CommandContext<ServerCommandSource> context) {
        ClickableChaosCommands.handleReset(context.getSource());
        return 1;
    }
    
    private static int handleRefresh(CommandContext<ServerCommandSource> context) {
        ClickableChaosCommands.showMainMenu(context);
        return 1;
    }
}

