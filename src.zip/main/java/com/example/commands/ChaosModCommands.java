package com.example.commands;

import com.example.ChaosMod;
import com.example.config.ChaosModConfig;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

public class ChaosModCommands {
    
    public static void register() {
        // 注册命令将在模组初始化时调用
    }
    
    public static void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher, CommandRegistryAccess registryAccess) {
        dispatcher.register(CommandManager.literal("chaosmod")
            .requires(source -> source.hasPermissionLevel(2))
            .then(CommandManager.literal("foodpoison")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::toggleFoodPoison)))
            .then(CommandManager.literal("mobignite")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::toggleMobIgnite)))
            .then(CommandManager.literal("mobslowness")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::toggleMobSlowness)))
            .then(CommandManager.literal("mobblindness")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::toggleMobBlindness)))
            .then(CommandManager.literal("mobthorns")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::toggleMobThorns)))
            .then(CommandManager.literal("enderdragonbucket")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::toggleEnderDragonBucket)))
            .then(CommandManager.literal("enderdragonkill")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::toggleEnderDragonKill)))
            .then(CommandManager.literal("playerdamageshare")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::togglePlayerDamageShare)))
            .then(CommandManager.literal("shieldnerf")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::toggleShieldNerf)))
            .then(CommandManager.literal("allhostile")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::toggleAllHostile)))
            .then(CommandManager.literal("randomdamage")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::toggleRandomDamage)))
            .then(CommandManager.literal("lowhealthnoheal")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::toggleLowHealthNoHeal)))
            .then(CommandManager.literal("sharedhealth")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::toggleSharedHealth)))
            .then(CommandManager.literal("shareddamagesplit")
                .then(CommandManager.argument("enabled", BoolArgumentType.bool())
                    .executes(ChaosModCommands::toggleSharedDamageSplit)))
            .then(CommandManager.literal("status")
                .executes(ChaosModCommands::showStatus))
            .then(CommandManager.literal("reset")
                .executes(ChaosModCommands::resetAll)));
    }
    
    private static int toggleFoodPoison(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        config.foodPoisonEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("食物中毒效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int toggleMobIgnite(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        config.mobIgniteEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("怪物点燃效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int toggleMobSlowness(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        config.mobSlownessEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("怪物缓慢效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int toggleMobBlindness(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        config.mobBlindnessEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("怪物失明效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int toggleMobThorns(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        config.mobThornsEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("怪物反伤效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int toggleEnderDragonBucket(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        config.enderDragonBucketEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("末影龙水桶变牛奶效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int toggleEnderDragonKill(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        config.enderDragonKillEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("末影龙击杀死亡效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int togglePlayerDamageShare(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        
        // 检查冲突
        if (enabled && (config.sharedHealthEnabled || config.sharedDamageSplitEnabled)) {
            context.getSource().sendError(Text.literal("无法同时开启玩家平摊伤害、共享生命值和共享平摊伤害效果！"));
            return 0;
        }
        
        config.playerDamageShareEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("玩家平摊伤害效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int toggleShieldNerf(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        config.shieldNerfEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("盾牌削弱效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int toggleAllHostile(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        config.allHostileEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("所有生物敌对效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int toggleRandomDamage(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        config.randomDamageEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("随机伤害效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int toggleLowHealthNoHeal(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        config.lowHealthNoHealEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("低血量无法回血效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int toggleSharedHealth(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        
        // 检查冲突
        if (enabled && (config.playerDamageShareEnabled || config.sharedDamageSplitEnabled)) {
            context.getSource().sendError(Text.literal("无法同时开启玩家平摊伤害、共享生命值和共享平摊伤害效果！"));
            return 0;
        }
        
        config.sharedHealthEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("共享生命值效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int toggleSharedDamageSplit(CommandContext<ServerCommandSource> context) {
        boolean enabled = BoolArgumentType.getBool(context, "enabled");
        ChaosModConfig config = ChaosMod.config;
        
        // 检查冲突
        if (enabled && (config.playerDamageShareEnabled || config.sharedHealthEnabled)) {
            context.getSource().sendError(Text.literal("无法同时开启玩家平摊伤害、共享生命值和共享平摊伤害效果！"));
            return 0;
        }
        
        config.sharedDamageSplitEnabled = enabled;
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("共享平摊伤害效果: " + (enabled ? "开启" : "关闭")), true);
        return 1;
    }
    
    private static int showStatus(CommandContext<ServerCommandSource> context) {
        ChaosModConfig config = ChaosMod.config;
        
        StringBuilder status = new StringBuilder("=== 混乱模组状态 ===\n");
        status.append("食物中毒: ").append(config.foodPoisonEnabled ? "开启" : "关闭").append("\n");
        status.append("怪物点燃: ").append(config.mobIgniteEnabled ? "开启" : "关闭").append("\n");
        status.append("怪物缓慢: ").append(config.mobSlownessEnabled ? "开启" : "关闭").append("\n");
        status.append("怪物失明: ").append(config.mobBlindnessEnabled ? "开启" : "关闭").append("\n");
        status.append("怪物反伤: ").append(config.mobThornsEnabled ? "开启" : "关闭").append("\n");
        status.append("末影龙水桶变牛奶: ").append(config.enderDragonBucketEnabled ? "开启" : "关闭").append("\n");
        status.append("末影龙击杀死亡: ").append(config.enderDragonKillEnabled ? "开启" : "关闭").append("\n");
        status.append("玩家平摊伤害: ").append(config.playerDamageShareEnabled ? "开启" : "关闭").append("\n");
        status.append("盾牌削弱: ").append(config.shieldNerfEnabled ? "开启" : "关闭").append("\n");
        status.append("所有生物敌对: ").append(config.allHostileEnabled ? "开启" : "关闭").append("\n");
        status.append("随机伤害: ").append(config.randomDamageEnabled ? "开启" : "关闭").append("\n");
        status.append("低血量无法回血: ").append(config.lowHealthNoHealEnabled ? "开启" : "关闭").append("\n");
        status.append("共享生命值: ").append(config.sharedHealthEnabled ? "开启" : "关闭").append("\n");
        status.append("共享平摊伤害: ").append(config.sharedDamageSplitEnabled ? "开启" : "关闭").append("\n");
        
        context.getSource().sendFeedback(() -> Text.literal(status.toString()), false);
        return 1;
    }
    
    private static int resetAll(CommandContext<ServerCommandSource> context) {
        ChaosModConfig config = ChaosMod.config;
        
        config.foodPoisonEnabled = false;
        config.mobIgniteEnabled = false;
        config.mobSlownessEnabled = false;
        config.mobBlindnessEnabled = false;
        config.mobThornsEnabled = false;
        config.enderDragonBucketEnabled = false;
        config.enderDragonKillEnabled = false;
        config.playerDamageShareEnabled = false;
        config.shieldNerfEnabled = false;
        config.allHostileEnabled = false;
        config.randomDamageEnabled = false;
        config.lowHealthNoHealEnabled = false;
        config.sharedHealthEnabled = false;
        config.sharedDamageSplitEnabled = false;
        config.noHealActive = false;
        config.noHealEndTime = 0;
        
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("所有效果已重置为关闭状态"), true);
        return 1;
    }
}
