package com.example.commands;

import com.example.ChaosMod;
import com.example.config.ChaosModConfig;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

public class SimpleChaosCommands {
    
    public static void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher, CommandRegistryAccess registryAccess) {
        dispatcher.register(CommandManager.literal("chaos")
            .requires(source -> source.hasPermissionLevel(2))
            .then(CommandManager.argument("effect", StringArgumentType.string())
                .suggests((context, builder) -> {
                    builder.suggest("foodpoison");
                    builder.suggest("mobignite");
                    builder.suggest("mobslowness");
                    builder.suggest("mobblindness");
                    builder.suggest("mobthorns");
                    builder.suggest("enderdragonbucket");
                    builder.suggest("enderdragonkill");
                    builder.suggest("playerdamageshare");
                    builder.suggest("allhostile");
                    builder.suggest("randomdamage");
                    builder.suggest("lowhealthnoheal");
                    builder.suggest("sharedhealth");
                    builder.suggest("shareddamagesplit");
                    builder.suggest("status");
                    builder.suggest("reset");
                    return builder.buildFuture();
                })
                .executes(SimpleChaosCommands::toggleEffect)));
    }
    
    private static int toggleEffect(CommandContext<ServerCommandSource> context) {
        String effect = StringArgumentType.getString(context, "effect");
        ChaosModConfig config = ChaosMod.config;
        
        if (effect.equals("status")) {
            return showStatus(context);
        }
        
        if (effect.equals("reset")) {
            return resetAll(context);
        }
        
        // 切换效果
        boolean newState = !getEffectState(config, effect);
        setEffectState(config, effect, newState);
        
        String status = newState ? "开启" : "关闭";
        context.getSource().sendFeedback(() -> Text.literal("§6[混乱模组] §f" + getEffectName(effect) + " 已" + status), true);
        
        return 1;
    }
    
    private static boolean getEffectState(ChaosModConfig config, String effect) {
        return switch (effect) {
            case "foodpoison" -> config.foodPoisonEnabled;
            case "mobignite" -> config.mobIgniteEnabled;
            case "mobslowness" -> config.mobSlownessEnabled;
            case "mobblindness" -> config.mobBlindnessEnabled;
            case "mobthorns" -> config.mobThornsEnabled;
            case "enderdragonbucket" -> config.enderDragonBucketEnabled;
            case "enderdragonkill" -> config.enderDragonKillEnabled;
            case "playerdamageshare" -> config.playerDamageShareEnabled;
            case "allhostile" -> config.allHostileEnabled;
            case "randomdamage" -> config.randomDamageEnabled;
            case "lowhealthnoheal" -> config.lowHealthNoHealEnabled;
            case "sharedhealth" -> config.sharedHealthEnabled;
            case "shareddamagesplit" -> config.sharedDamageSplitEnabled;
            default -> false;
        };
    }
    
    private static void setEffectState(ChaosModConfig config, String effect, boolean state) {
        switch (effect) {
            case "foodpoison" -> config.foodPoisonEnabled = state;
            case "mobignite" -> config.mobIgniteEnabled = state;
            case "mobslowness" -> config.mobSlownessEnabled = state;
            case "mobblindness" -> config.mobBlindnessEnabled = state;
            case "mobthorns" -> config.mobThornsEnabled = state;
            case "enderdragonbucket" -> config.enderDragonBucketEnabled = state;
            case "enderdragonkill" -> config.enderDragonKillEnabled = state;
            case "playerdamageshare" -> config.playerDamageShareEnabled = state;
            case "allhostile" -> config.allHostileEnabled = state;
            case "randomdamage" -> config.randomDamageEnabled = state;
            case "lowhealthnoheal" -> config.lowHealthNoHealEnabled = state;
            case "sharedhealth" -> config.sharedHealthEnabled = state;
            case "shareddamagesplit" -> config.sharedDamageSplitEnabled = state;
        }
        config.markDirty();
    }
    
    private static String getEffectName(String effect) {
        return switch (effect) {
            case "foodpoison" -> "食物中毒";
            case "mobignite" -> "怪物点燃";
            case "mobslowness" -> "怪物缓慢";
            case "mobblindness" -> "怪物失明";
            case "mobthorns" -> "怪物反伤";
            case "enderdragonbucket" -> "末影龙水桶变牛奶";
            case "enderdragonkill" -> "末影龙击杀死亡";
            case "playerdamageshare" -> "玩家平摊伤害";
            case "allhostile" -> "所有生物敌对";
            case "randomdamage" -> "随机伤害";
            case "lowhealthnoheal" -> "低血量无法回血";
            case "sharedhealth" -> "共享生命值";
            case "shareddamagesplit" -> "共享平摊伤害";
            default -> "未知效果";
        };
    }
    
    private static int showStatus(CommandContext<ServerCommandSource> context) {
        ChaosModConfig config = ChaosMod.config;
        
        StringBuilder status = new StringBuilder("§6=== 混乱模组状态 ===\n");
        status.append("§f食物中毒: ").append(config.foodPoisonEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f怪物点燃: ").append(config.mobIgniteEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f怪物缓慢: ").append(config.mobSlownessEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f怪物失明: ").append(config.mobBlindnessEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f怪物反伤: ").append(config.mobThornsEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f末影龙水桶变牛奶: ").append(config.enderDragonBucketEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f末影龙击杀死亡: ").append(config.enderDragonKillEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f玩家平摊伤害: ").append(config.playerDamageShareEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f所有生物敌对: ").append(config.allHostileEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f随机伤害: ").append(config.randomDamageEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f低血量无法回血: ").append(config.lowHealthNoHealEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f共享生命值: ").append(config.sharedHealthEnabled ? "§a开启" : "§c关闭").append("\n");
        status.append("§f共享平摊伤害: ").append(config.sharedDamageSplitEnabled ? "§a开启" : "§c关闭");
        
        context.getSource().sendFeedback(() -> Text.literal(status.toString()), false);
        return 1;
    }
    
    private static int resetAll(CommandContext<ServerCommandSource> context) {
        ChaosModConfig config = ChaosMod.config;
        
        config.foodPoisonEnabled = false;
        config.mobIgniteEnabled = false;
        config.mobSlownessEnabled = false;
        config.mobBlindnessEnabled = false;
        config.mobThornsEnabled = false;
        config.enderDragonBucketEnabled = false;
        config.enderDragonKillEnabled = false;
        config.playerDamageShareEnabled = false;
        config.allHostileEnabled = false;
        config.randomDamageEnabled = false;
        config.lowHealthNoHealEnabled = false;
        config.sharedHealthEnabled = false;
        config.sharedDamageSplitEnabled = false;
        config.noHealActive = false;
        config.noHealEndTime = 0;
        
        config.markDirty();
        
        context.getSource().sendFeedback(() -> Text.literal("§6[混乱模组] §f所有效果已重置为关闭状态"), true);
        return 1;
    }
}

