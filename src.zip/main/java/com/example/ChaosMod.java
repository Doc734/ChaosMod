package com.example;

import com.example.commands.ClickableChaosCommands;
import com.example.commands.InternalChaosCommands;
import com.example.config.ChaosModConfig;
import com.example.effects.ChaosModEffects;
import com.example.events.ChaosModEvents;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChaosMod implements ModInitializer {
	public static final String MOD_ID = "chaosmod";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	
	public static ChaosModConfig config;
	public static MinecraftServer server;

	@Override
	public void onInitialize() {
		LOGGER.info("Initializing Chaos Mod!");
		
		// Initialize config
		config = new ChaosModConfig();
		
		// Register effects
		ChaosModEffects.register();
		
		// Register events
		ChaosModEvents.register();
		
        // Register commands
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            ClickableChaosCommands.registerCommands(dispatcher, registryAccess);
            InternalChaosCommands.registerCommands(dispatcher, registryAccess);
        });
		
		// Register server events
		ServerWorldEvents.LOAD.register((server, world) -> {
			ChaosMod.server = server;
		});
		
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			ChaosMod.server = server;
		});
		
		LOGGER.info("Chaos Mod initialized successfully!");
	}
}